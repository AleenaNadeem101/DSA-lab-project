package GUI;

import javax.swing.JFrame;

public class Jframe extends JFrame {
    public Jframe()
    {
        this.setTitle("CV Searcher");
        this.setSize(500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
